document.getElementById('convert').addEventListener('click', () => {
    const tempInput = document.getElementById('temperature').value;
    const unit = document.getElementById('unit').value;
    const resultElem = document.getElementById('converted-temperature');
    const thermometerBar = document.querySelector('.thermometer-bar');

    if (isNaN(tempInput) || tempInput === '') {
        resultElem.textContent = 'Please enter a valid number.';
        return;
    }

    const temp = parseFloat(tempInput);
    let convertedTemp;
    let displayUnit;

    switch (unit) {
        case 'C':
            convertedTemp = {
                F: (temp * 9/5) + 32,
                K: temp + 273.15
            };
            displayUnit = 'Celsius';
            break;
        case 'F':
            convertedTemp = {
                C: (temp - 32) * 5/9,
                K: (temp - 32) * 5/9 + 273.15
            };
            displayUnit = 'Fahrenheit';
            break;
        case 'K':
            convertedTemp = {
                C: temp - 273.15,
                F: (temp - 273.15) * 9/5 + 32
            };
            displayUnit = 'Kelvin';
            break;
    }

    resultElem.innerHTML = `
        <p>${convertedTemp.C ? `Celsius: ${convertedTemp.C.toFixed(2)} °C` : ''}</p>
        <p>${convertedTemp.F ? `Fahrenheit: ${convertedTemp.F.toFixed(2)} °F` : ''}</p>
        <p>${convertedTemp.K ? `Kelvin: ${convertedTemp.K.toFixed(2)} K` : ''}</p>
    `;

    const maxTemp = 100; 
    const minTemp = -100;
    let thermometerHeight = 0;

    if (unit === 'C') {
        thermometerHeight = ((temp - minTemp) / (maxTemp - minTemp)) * 100;
    } else if (unit === 'F') {
        const tempC = (temp - 32) * 5/9;
        thermometerHeight = ((tempC - minTemp) / (maxTemp - minTemp)) * 100;
    } else if (unit === 'K') {
        const tempC = temp - 273.15;
        thermometerHeight = ((tempC - minTemp) / (maxTemp - minTemp)) * 100;
    }

    thermometerBar.style.height = thermometerHeight + '%';
});
